const API_URL = 'http://localhost:3000/api';

// ========================
// Регистрация
// ========================
async function registerUser(event) {
    event.preventDefault();

    const full_name = document.getElementById('full_name').value;
    const email = document.getElementById('email').value;
    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ full_name, email, login, password, role })
        });

        const data = await response.json();

        document.getElementById('message').textContent =
            data.message || data.error || 'Ошибка регистрации';

        if (response.ok && data.message === 'Регистрация успешна') {
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1000);
        }
    } catch (error) {
        console.error('Ошибка подключения к серверу:', error);
        document.getElementById('message').textContent =
            'Сервер недоступен. Проверь, запущен ли backend.';
    }
}

// ========================
// Авторизация
// ========================
async function loginUser(event) {
    event.preventDefault();

    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ login, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('user', JSON.stringify(data.user));
            document.getElementById('message').textContent =
                `Добро пожаловать, ${data.user.full_name} (${data.user.role})`;

            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);
        } else {
            document.getElementById('message').textContent =
                data.message || data.error || 'Ошибка входа';
        }
    } catch (error) {
        console.error('Ошибка подключения к серверу:', error);
        document.getElementById('message').textContent =
            'Сервер недоступен. Проверь, запущен ли backend.';
    }
}

// ========================
// Проверка авторизации
// ========================
function getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

function requireAuth() {
    const user = getCurrentUser();
    if (!user) {
        alert('Сначала войдите в аккаунт.');
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// ========================
// Показ текущего пользователя
// ========================
function showUserInfo() {
    const userBlock = document.getElementById('user-info');
    if (!userBlock) return;

    const user = getCurrentUser();
    if (user) {
        userBlock.innerHTML = `
            <p><strong>Пользователь:</strong> ${user.full_name}</p>
            <p><strong>Роль:</strong> ${user.role}</p>
            <button onclick="logout()">Выйти</button>
        `;
    } else {
        userBlock.innerHTML = `
            <p>Вы не вошли в систему</p>
            <a href="login.html">Войти</a>
        `;
    }
}

// ========================
// Загрузка статей о белках
// ========================
async function loadArticles() {
    if (!requireAuth()) return;

    try {
        const response = await fetch(`${API_URL}/articles`);
        const articles = await response.json();

        const container = document.getElementById('articles-list');
        if (!container) return;
        container.innerHTML = '';

        if (articles.length === 0) {
            container.innerHTML = '<p>Пока нет ни одной статьи.</p>';
            return;
        }

        articles.forEach(article => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <h3>${article.title}</h3>
                <p><strong>Описание:</strong> ${article.description || 'Нет описания'}</p>
                <p><strong>Автор:</strong> ${article.author || 'Неизвестный бельчонок'}</p>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error('Ошибка загрузки статей:', error);
        const container = document.getElementById('articles-list');
        if (container) {
            container.innerHTML = '<p>Не удалось загрузить статьи.</p>';
        }
    }
}

// ========================
// Загрузка предпочтений белок
// ========================
async function loadPreferences() {
    if (!requireAuth()) return;

    try {
        const response = await fetch(`${API_URL}/preferences`);
        const prefs = await response.json();

        const container = document.getElementById('preferences-list');
        if (!container) return;
        container.innerHTML = '';

        if (prefs.length === 0) {
            container.innerHTML = '<p>Предпочтения ещё не добавлены.</p>';
            return;
        }

        const grouped = {};
        prefs.forEach(p => {
            if (!grouped[p.squirrel_name]) {
                grouped[p.squirrel_name] = {
                    color: p.color,
                    nuts: []
                };
            }
            grouped[p.squirrel_name].nuts.push(p.nut_type);
        });

        for (const [squirrel, info] of Object.entries(grouped)) {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <h3>${squirrel} ${info.color ? `(${info.color})` : ''}</h3>
                <p><strong>Любимые орехи:</strong> ${info.nuts.join(', ') || 'неизвестно'}</p>
            `;
            container.appendChild(card);
        }
    } catch (error) {
        console.error('Ошибка загрузки предпочтений:', error);
        const container = document.getElementById('preferences-list');
        if (container) {
            container.innerHTML = '<p>Не удалось загрузить данные о предпочтениях.</p>';
        }
    }
}

// ========================
// Автозагрузка по странице
// ========================
document.addEventListener('DOMContentLoaded', () => {
    showUserInfo();

    if (document.getElementById('articles-list')) {
        loadArticles();
    }

    if (document.getElementById('preferences-list')) {
        loadPreferences();
    }
});