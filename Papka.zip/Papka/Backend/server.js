const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const articlesRoutes = require('./routes/articles');

const app = express();

app.use(cors());
app.use(express.json());
const path = require('path');
app.use(express.static(path.join(__dirname, 'frontend')));

app.use('/api/auth', authRoutes);
app.use('/api', articlesRoutes);

app.get('/', (req, res) => {
    res.send('БЕЛИЧИЙ API работает');
});

app.get('/api', (req, res) => {
    res.json({
        message: 'API root',
        endpoints: {
            register: 'POST /api/auth/register',
            login: 'POST /api/auth/login',
            articles: 'GET /api/articles',
            preferences: 'GET /api/preferences'
        }
    });
});

app.use((req, res) => {
    res.status(404).json({ error: 'Маршрут не найден' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});