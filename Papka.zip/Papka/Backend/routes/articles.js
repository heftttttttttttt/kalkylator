const express = require('express');
const router = express.Router();
const pool = require('../db');

router.get('/articles', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT
                s.id,
                s.title,
                s.description,
                u.full_name AS author
            FROM squirrel_facts s
            LEFT JOIN users u ON s.user_id = u.id
            ORDER BY s.id`
        );
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Ошибка получения статей о белках' });
    }
});

router.get('/preferences', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                snp.squirrel_id,
                s.name AS squirrel_name,
                s.color,
                n.type AS nut_type,
                n.id AS nut_id
            FROM squirrel_nut_preference snp
            JOIN squirrels s ON snp.squirrel_id = s.id
            JOIN nuts n ON snp.nut_id = n.id
            ORDER BY s.name, n.type
        `);
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Ошибка получения предпочтений белок' });
    }
});

module.exports = router;