const express = require('express');
const router = express.Router();
const pool = require('../db');

router.post('/register', async (req, res) => {
    try {
        const { full_name, email, login, password, role } = req.body;

        if (!full_name || !email || !login || !password) {
            return res.status(400).json({ error: 'Заполните все поля' });
        }

        const result = await pool.query(
            `INSERT INTO users (full_name, email, login, password, role)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING id, full_name, email, login, role, created_at`,
            [full_name, email, login, password, role || 'user']
        );

        res.status(201).json({
            message: 'Регистрация успешна',
            user: result.rows[0]
        });
    } catch (error) {
        console.error('Ошибка регистрации:', error);

        if (error.code === '23505') {
            return res.status(409).json({ error: 'Пользователь с таким email или логином уже существует' });
        }

        res.status(500).json({ error: 'Ошибка регистрации' });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { login, password } = req.body;

        const result = await pool.query(
            'SELECT * FROM authorize_user($1, $2)',
            [login, password]
        );

        const user = result.rows[0];

        if (!user || !user.user_id) {
            return res.status(401).json({ message: 'Неверный логин или пароль' });
        }

        res.json({
            message: user.auth_status,
            user: {
                id: user.user_id,
                full_name: user.full_name,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        console.error('Ошибка авторизации:', error);
        res.status(500).json({ error: 'Ошибка авторизации' });
    }
});

module.exports = router;